package com.example.facebook_login_screen_replication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
