// En este archivo se encontrarán los íconos que se ven en la parte superior de
// la pantalla de inicio de Facebook.
